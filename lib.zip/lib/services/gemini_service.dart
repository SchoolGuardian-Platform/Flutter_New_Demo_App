import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/api_config.dart';

/// Message in a Gemini chat session.
class GeminiMessage {
  const GeminiMessage({required this.role, required this.text});
  final String role; // 'user' or 'model'
  final String text;
}

/// Service that calls the Gemini 2.0 Flash free-tier API.
///
/// When no API key is configured, falls back to a smart on-device
/// study assistant that reads the user's actual question and gives
/// context-aware, varied responses.
class GeminiService {
  GeminiService._internal();
  static final GeminiService _instance = GeminiService._internal();
  factory GeminiService() => _instance;

  /// Sends a prompt (with optional conversation history) to Gemini and returns
  /// the model's reply text, or a smart fallback if no API key is set.
  Future<String> ask(
    String userPrompt, {
    String? systemContext,
    List<GeminiMessage> history = const [],
  }) async {
    final apiKey = ApiConfig.geminiApiKey;
    if (apiKey == 'YOUR_GEMINI_API_KEY_HERE' || apiKey.isEmpty) {
      // No key — use the smart local study assistant
      return _LocalStudyAI.respond(
        userPrompt,
        systemContext: systemContext,
        history: history,
      );
    }

    // Build the contents array: system context as first user turn if provided
    final contents = <Map<String, dynamic>>[];

    if (systemContext != null && systemContext.isNotEmpty) {
      contents.add({
        'role': 'user',
        'parts': [
          {'text': systemContext}
        ],
      });
      contents.add({
        'role': 'model',
        'parts': [
          {'text': 'Understood. I will help the student with this homework assignment.'}
        ],
      });
    }

    // Add conversation history
    for (final msg in history) {
      contents.add({
        'role': msg.role,
        'parts': [
          {'text': msg.text}
        ],
      });
    }

    // Add current user question
    contents.add({
      'role': 'user',
      'parts': [
        {'text': userPrompt}
      ],
    });

    final requestBody = {
      'contents': contents,
      'generationConfig': {
        'temperature': 0.7,
        'topK': 40,
        'topP': 0.95,
        'maxOutputTokens': 1024,
      },
      'safetySettings': [
        {'category': 'HARM_CATEGORY_HARASSMENT', 'threshold': 'BLOCK_MEDIUM_AND_ABOVE'},
        {'category': 'HARM_CATEGORY_HATE_SPEECH', 'threshold': 'BLOCK_MEDIUM_AND_ABOVE'},
      ],
    };

    final modelEndpoints = [
      ApiConfig.geminiBaseUrl,
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent',
    ];

    for (int i = 0; i < modelEndpoints.length; i++) {
      final endpoint = modelEndpoints[i];
      try {
        final uri = Uri.parse('$endpoint?key=$apiKey');
        final response = await http
            .post(
              uri,
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode(requestBody),
            )
            .timeout(const Duration(seconds: 30));

        if (response.statusCode == 200) {
          final decoded = jsonDecode(response.body) as Map<String, dynamic>;
          final candidates = decoded['candidates'] as List<dynamic>?;
          if (candidates != null && candidates.isNotEmpty) {
            final content = candidates[0]['content'] as Map<String, dynamic>?;
            final parts = content?['parts'] as List<dynamic>?;
            if (parts != null && parts.isNotEmpty) {
              return parts[0]['text'] as String? ?? 'No response from AI.';
            }
          }
          return 'The AI returned an unexpected response format.';
        } else if (response.statusCode == 404 && i < modelEndpoints.length - 1) {
          continue;
        } else if (response.statusCode == 400) {
          return '❌ Invalid request. Please check your API key or try again.';
        } else if (response.statusCode == 429) {
          return '⏳ Rate limit reached. Please wait a moment before asking again.';
        } else if (response.statusCode == 403) {
          return '🔑 API key error. Please verify your Gemini API key is correct.';
        } else {
          return '❌ AI service error (${response.statusCode}). Please try again.';
        }
      } catch (e) {
        if (i < modelEndpoints.length - 1) continue;
        return '🌐 Network error. Please check your internet connection and try again.';
      }
    }
    return '❌ AI service unavailable. Please try again.';
  }
}

// ─── Local Study AI (offline fallback) ────────────────────────────────────────

/// A lightweight rule-based study assistant that runs entirely on-device when
/// no Gemini API key is configured. It reads the user's actual question,
/// extracts the homework subject/title from the system context, and generates
/// a relevant, varied response rather than returning the same static message.
class _LocalStudyAI {
  _LocalStudyAI._();

  static String respond(
    String userPrompt, {
    String? systemContext,
    List<GeminiMessage> history = const [],
  }) {
    final q = userPrompt.toLowerCase().trim();
    final subject = _extractSubject(systemContext);
    final title = _extractTitle(systemContext);
    final turnCount = history.length;

    // ── Greetings ─────────────────────────────────────────────────────────
    if (_any(q, ['hi', 'hello', 'hey', 'hiya', 'good morning', 'good afternoon', 'sup'])) {
      return '👋 Hey there! I\'m your study assistant for "$title".\n\n'
          'What would you like help with? You can ask me to:\n'
          '• Explain a concept from your assignment\n'
          '• Help you understand a tricky question\n'
          '• Give you a study strategy for $subject\n\n'
          'Go ahead — what\'s on your mind? 😊';
    }

    // ── Off-topic / social ────────────────────────────────────────────────
    if (_any(q, ['i love you', 'love u', 'love you', 'i like you', 'marry me'])) {
      return '😄 Haha, thank you — I\'m flattered! But let\'s channel that energy into acing your $subject work.\n\n'
          'What topic in "$title" can I help you understand better? 📚';
    }

    // ── What is / define ──────────────────────────────────────────────────
    if (_any(q, ['what is', 'what are', 'define', 'definition', 'meaning of', 'explain what'])) {
      final topic = _after(q, ['what is', 'what are', 'define', 'definition of', 'meaning of', 'explain what']);
      return '🔍 Great question about "$topic"!\n\n'
          'Here\'s how to approach understanding this for your $subject assignment:\n\n'
          '**1. Core definition** — Write the simplest one-sentence definition you can.\n\n'
          '**2. Context in your assignment** — How does "$topic" appear in "$title"? What role does it play?\n\n'
          '**3. Real-world connection** — Name one example from everyday life that matches.\n\n'
          '💡 Try writing your own definition first, then I\'ll help you refine it. '
          'What do *you* think "$topic" means in your own words?';
    }

    // ── How to / how does ─────────────────────────────────────────────────
    if (_any(q, ['how to', 'how do', 'how does', 'how can', 'how should', 'steps to', 'steps for'])) {
      final topic = _after(q, ['how to', 'how do', 'how does', 'how can', 'how should', 'steps to', 'steps for']);
      return '📋 Breaking it into steps — smart approach!\n\n'
          'For "$topic" in your $subject assignment:\n\n'
          '**Step 1 — Understand the Goal:** What\'s the desired end result?\n\n'
          '**Step 2 — Gather What You Know:** List relevant facts or formulas from "$title".\n\n'
          '**Step 3 — Apply Logically:** Work through each part in order — don\'t skip steps.\n\n'
          '**Step 4 — Verify:** Does the result make sense? Can you explain it simply?\n\n'
          '🤔 Which specific step feels most challenging right now?';
    }

    // ── Why / reason ──────────────────────────────────────────────────────
    if (_any(q, ['why', 'what causes', 'reason for', 'purpose of', 'why does', 'why is', 'why do'])) {
      final topic = _after(q, ['why is', 'why are', 'why does', 'why do', 'why', 'what causes', 'reason for', 'purpose of']);
      return '💡 "Why" questions show you\'re thinking critically — excellent!\n\n'
          'To understand why "$topic" works the way it does in $subject:\n\n'
          '🔗 **Cause & Effect:** What happens *before* it? What happens *because* of it?\n\n'
          '🌍 **Real-World Grounding:** Where have you seen this in real life?\n\n'
          '📖 **Back to the Source:** Check your instructions in "$title" — the reason is usually hinted there.\n\n'
          '✍️ Try completing: *"$topic happens because ___"*\n'
          'What would you fill in?';
    }

    // ── Examples ──────────────────────────────────────────────────────────
    if (_any(q, ['example', 'examples', 'give me', 'show me', 'can you give', 'such as', 'like what'])) {
      return '✅ Examples are one of the best ways to make knowledge stick!\n\n'
          'For your $subject assignment "$title":\n\n'
          '**1. Start with the simplest case** — The most basic example reveals the core idea.\n\n'
          '**2. Look inside the assignment** — "$title" may already have a model scenario you can adapt.\n\n'
          '**3. Use your own experience** — Is there anything from daily life that works the same way? Connecting new ideas to familiar ones is very powerful.\n\n'
          '💬 What specific concept are you looking for an example of? Tell me and I\'ll guide you through building one!';
    }

    // ── Compare / difference ──────────────────────────────────────────────
    if (_any(q, ['difference between', 'compare', ' vs ', 'versus', 'similarities', 'contrast'])) {
      return '⚖️ Comparing is a great study technique!\n\n'
          'For your $subject comparison, try this table:\n\n'
          '| Aspect       | Concept A | Concept B |\n'
          '|--------------|-----------|-----------|\n'
          '| Definition   |     ?     |     ?     |\n'
          '| Key feature  |     ?     |     ?     |\n'
          '| Example      |     ?     |     ?     |\n'
          '| Main diff.   |     —     |     —     |\n\n'
          '📝 Try filling it in from your "$title" notes.\n\n'
          'What two things are you comparing? Share them and I\'ll give you more specific guiding questions!';
    }

    // ── Stuck / confused / help ───────────────────────────────────────────
    if (_any(q, ['help', 'stuck', "don't understand", 'confused', "can't", 'lost', 'difficult', 'hard', 'don\'t get'])) {
      return '🤗 Feeling stuck is completely normal — and that\'s exactly why I\'m here!\n\n'
          'Let\'s tackle "$title" together. Here\'s what usually breaks the block in $subject:\n\n'
          '🔄 **Go back to basics** — What\'s the last concept you *did* understand? Start there.\n\n'
          '✏️ **Write something, anything** — Even an incorrect attempt shows your brain what\'s missing.\n\n'
          '🗣️ **Say it out loud** — Explain what you think the question is asking. You\'ll spot the gap yourself.\n\n'
          '❓ **Pick one sentence** — Instead of "I don\'t get all of it," find *one* sentence or step that confuses you.\n\n'
          'Which part of the assignment is giving you trouble right now? Let\'s zoom in on just that. 🎯';
    }

    // ── Biology keywords ──────────────────────────────────────────────────
    if (subject.toLowerCase().contains('bio') &&
        _any(q, ['organism', 'cell', 'micro', 'bacteria', 'virus', 'dna', 'gene', 'photosynthesis', 'evolution', 'life', 'microorganism'])) {
      return '🧬 Great biology question for "$title"!\n\n'
          'Use the **SCALE approach** for any biological concept:\n\n'
          '• **S**tructure — What does it look like / what parts does it have?\n'
          '• **C**haracteristics — What defines it?\n'
          '• **A**ction — What does it *do*?\n'
          '• **L**ocation — Where is it found?\n'
          '• **E**xample — Can you name a real-world specimen?\n\n'
          'For example, a **microorganism** is a living thing too small to see without a microscope (Structure), '
          'it can be single-celled (Characteristic), it eats, reproduces and responds (Action), '
          'found in soil, water, and inside our bodies (Location), e.g. *E. coli* bacteria (Example).\n\n'
          'Try applying SCALE to the specific organism or concept your assignment mentions!';
    }

    // ── Maths keywords ────────────────────────────────────────────────────
    if (_any(subject.toLowerCase(), ['math', 'algebra', 'calc', 'statistic', 'geometry']) &&
        _any(q, ['solve', 'calculate', 'equation', 'formula', 'graph', 'variable', 'number', 'function'])) {
      return '🔢 Maths becomes clearer when you build it step by step!\n\n'
          'For "$title":\n\n'
          '1️⃣ **Write down what\'s given** — List every number and fact in the problem.\n'
          '2️⃣ **Name the unknown** — What are you solving for? Assign it a letter (x, y, n…).\n'
          '3️⃣ **Choose your method** — Which formula or rule from class applies?\n'
          '4️⃣ **Substitute & solve** — Plug values in step by step, showing every line.\n'
          '5️⃣ **Verify** — Substitute your answer back. Does both sides balance?\n\n'
          '✏️ Write out the exact problem for me and let\'s work through Step 1 together.';
    }

    // ── Varied default by conversation depth ──────────────────────────────
    if (turnCount <= 1) {
      return '🤔 Interesting — tell me more about what you\'re working on!\n\n'
          'To help you best with your $subject assignment "$title", I need a bit more detail:\n\n'
          '• What exactly does the question or task ask you to do?\n'
          '• What have you already tried or thought about?\n'
          '• Which specific word or idea is unclear?\n\n'
          'The more specific you are, the more targeted my guidance can be. '
          'I won\'t give you the answer — but I\'ll walk you through it step by step. 💪';
    } else if (turnCount <= 4) {
      return '💭 Good follow-up — you\'re pushing your thinking deeper!\n\n'
          'Here\'s an exercise for your $subject work on "$title":\n\n'
          '✍️ Write your best attempt at an answer — even if you\'re not sure it\'s right. '
          'Don\'t worry about being wrong.\n\n'
          'Once you write something, re-read it carefully. You\'ll usually spot what\'s incomplete or '
          'off on your own — that\'s your brain actively processing and learning!\n\n'
          'What\'s your best guess so far? Share it and I\'ll help you sharpen it.';
    } else {
      return '🌟 You\'ve been working hard on this — great persistence!\n\n'
          'Let\'s consolidate your understanding of "$title":\n\n'
          '📌 **List 3 things** you now understand better than when you started.\n\n'
          '❓ **Identify your one remaining gap** — What is the single thing that would make everything click?\n\n'
          '🎯 **Ask me about that one gap** — We\'ll focus all our energy right there.\n\n'
          'Learning is a process, not a race. You\'re doing great — what\'s your remaining question?';
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  static String _extractSubject(String? ctx) {
    if (ctx == null) return 'your subject';
    final m = RegExp(r'Subject:\s*(.+)', multiLine: true).firstMatch(ctx);
    return m?.group(1)?.trim() ?? 'your subject';
  }

  static String _extractTitle(String? ctx) {
    if (ctx == null) return 'your assignment';
    final m = RegExp(r'Assignment Title:\s*(.+)', multiLine: true).firstMatch(ctx);
    return m?.group(1)?.trim() ?? 'your assignment';
  }

  static bool _any(String q, List<String> keywords) =>
      keywords.any((k) => q.contains(k));

  static String _after(String q, List<String> prefixes) {
    for (final p in prefixes) {
      final idx = q.indexOf(p);
      if (idx != -1) {
        final after = q.substring(idx + p.length).trim();
        if (after.isNotEmpty) return after.replaceAll('?', '').trim();
      }
    }
    return q.replaceAll('?', '').trim();
  }
}
