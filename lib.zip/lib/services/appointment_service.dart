import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/api_config.dart';
import '../core/token_storage.dart';

class AppointmentSlotItem {
  final String id;
  final String date;
  final String startTime;
  final String endTime;
  final bool isBooked;

  AppointmentSlotItem({
    required this.id,
    required this.date,
    required this.startTime,
    required this.endTime,
    this.isBooked = false,
  });

  factory AppointmentSlotItem.fromJson(Map<String, dynamic> json) {
    return AppointmentSlotItem(
      id: json['id'] as String? ?? '',
      date: json['date'] as String? ?? '',
      startTime: json['startTime'] as String? ?? '',
      endTime: json['endTime'] as String? ?? '',
      isBooked: json['isBooked'] as bool? ?? false,
    );
  }
}

class AppointmentItem {
  final String id;
  final String parentName;
  final String parentEmail;
  final String studentName;
  final String date;
  final String startTime;
  final String endTime;
  final String reason;
  final String status;

  AppointmentItem({
    required this.id,
    required this.parentName,
    required this.parentEmail,
    required this.studentName,
    required this.date,
    required this.startTime,
    required this.endTime,
    required this.reason,
    required this.status,
  });

  factory AppointmentItem.fromJson(Map<String, dynamic> json) {
    String pName = 'Parent';
    String pEmail = '';
    if (json['parent'] != null && json['parent'] is Map<String, dynamic>) {
      final p = json['parent'] as Map<String, dynamic>;
      pName = '${p['firstName'] ?? ''} ${p['lastName'] ?? ''}'.trim();
      pEmail = p['email'] as String? ?? '';
    }

    String sName = 'Student';
    if (json['student'] != null && json['student'] is Map<String, dynamic>) {
      final s = json['student'] as Map<String, dynamic>;
      sName = '${s['firstName'] ?? ''} ${s['lastName'] ?? ''}'.trim();
    }

    String dt = '';
    String st = '';
    String et = '';
    if (json['slot'] != null && json['slot'] is Map<String, dynamic>) {
      final sl = json['slot'] as Map<String, dynamic>;
      dt = sl['date'] as String? ?? '';
      st = sl['startTime'] as String? ?? '';
      et = sl['endTime'] as String? ?? '';
    }

    return AppointmentItem(
      id: json['id'] as String? ?? 'apt-${DateTime.now().millisecondsSinceEpoch}',
      parentName: pName.isNotEmpty ? pName : 'Parent',
      parentEmail: pEmail,
      studentName: sName.isNotEmpty ? sName : 'Student',
      date: dt.isNotEmpty ? dt : (json['date'] as String? ?? ''),
      startTime: st.isNotEmpty ? st : (json['startTime'] as String? ?? ''),
      endTime: et.isNotEmpty ? et : (json['endTime'] as String? ?? ''),
      reason: json['reason'] as String? ?? 'General Conference Request',
      status: json['status'] as String? ?? 'PENDING',
    );
  }
}

class AppointmentService {
  Future<List<AppointmentItem>> getTeacherAppointments() async {
    try {
      final token = await TokenStorage().readAccessToken();
      final headers = {
        'Accept': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };
      final res = await http
          .get(Uri.parse('${ApiConfig.baseUrl}/api/appointments/teacher'), headers: headers)
          .timeout(ApiConfig.requestTimeout);

      if (res.statusCode == 200) {
        final body = json.decode(res.body);
        final list = (body['data'] as List<dynamic>?) ?? [];
        return list.map((e) => AppointmentItem.fromJson(e as Map<String, dynamic>)).toList();
      }
    } catch (_) {}
    return [];
  }

  Future<bool> createSlot({
    required String date,
    required String startTime,
    required String endTime,
  }) async {
    try {
      final token = await TokenStorage().readAccessToken();
      final headers = {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };
      final body = json.encode({
        'date': date,
        'startTime': startTime,
        'endTime': endTime,
      });

      final res = await http
          .post(
            Uri.parse('${ApiConfig.baseUrl}/api/appointments/slots'),
            headers: headers,
            body: body,
          )
          .timeout(ApiConfig.requestTimeout);

      return res.statusCode == 200 || res.statusCode == 201;
    } catch (_) {
      return false;
    }
  }

  Future<bool> updateAppointmentStatus(String appointmentId, String status) async {
    try {
      final token = await TokenStorage().readAccessToken();
      final headers = {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };
      final body = json.encode({'status': status});

      final res = await http
          .patch(
            Uri.parse('${ApiConfig.baseUrl}/api/appointments/$appointmentId/status'),
            headers: headers,
            body: body,
          )
          .timeout(ApiConfig.requestTimeout);

      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }
}
