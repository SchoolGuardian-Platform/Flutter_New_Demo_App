import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/api_exception.dart';
import '../../models/homework_entry.dart';
import '../../models/school_class.dart';
import '../../services/homework_service.dart';
import '../../services/school_management_service.dart';
import '../../services/teacher_service.dart';
import '../../theme/kukie_accent.dart';

class ManageHomeworkPage extends StatefulWidget {
  const ManageHomeworkPage({super.key});

  static const routeName = '/teacher/manage-homework';

  @override
  State<ManageHomeworkPage> createState() => _ManageHomeworkPageState();
}

class _ManageHomeworkPageState extends State<ManageHomeworkPage> {
  final _homeworkService = HomeworkService();
  final _schoolService = SchoolManagementService();
  final _teacherService = TeacherService();

  List<HomeworkEntry> _homeworks = [];
  List<SchoolClass> _classes = [];
  List<String> _teacherSubjects = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    try {
      final hwList = await _homeworkService.getTeacherHomeworks();
      final profile = await _teacherService.getTeacherProfile();
      final allClasses = await _schoolService.getClasses();
      final allSubjects = await _schoolService.getSubjects();

      final teacherClasses = allClasses.where((c) {
        final isAssignedByJoin = c.teachers.any((t) =>
            t.teacherId == profile.id ||
            t.teacherName.toLowerCase() == profile.fullName.toLowerCase());
        final isAssignedByName = profile.assignedClasses.contains(c.displayName) ||
            profile.assignedClasses.contains(c.shortLabel);
        return isAssignedByJoin || isAssignedByName;
      }).toList();

      final Set<String> subjSet = {};
      for (final s in profile.assignedSubjects) {
        if (s.trim().isNotEmpty) subjSet.add(s.trim());
      }
      if (subjSet.isEmpty) {
        for (final s in allSubjects) {
          if (s.name.trim().isNotEmpty) subjSet.add(s.name.trim());
        }
      }

      if (mounted) {
        setState(() {
          _homeworks = hwList;
          _classes = teacherClasses.isNotEmpty ? teacherClasses : allClasses;
          _teacherSubjects = subjSet.toList()..sort();
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  Future<void> _showCreateHomeworkDialog() async {
    final titleCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final profile = await _teacherService.getTeacherProfile();

    SchoolClass? selectedClass = _classes.isNotEmpty ? _classes.first : null;

    List<String> getAvailableSubjects(SchoolClass? cls) {
      if (cls != null && cls.teachers.isNotEmpty) {
        final classSubjs = <String>[];
        for (final t in cls.teachers) {
          final matchesTeacher = t.teacherId == profile.id ||
              t.teacherName.toLowerCase() == profile.fullName.toLowerCase();
          if (matchesTeacher && t.subjectName.trim().isNotEmpty) {
            classSubjs.add(t.subjectName.trim());
          }
        }
        if (classSubjs.isEmpty) {
          for (final t in cls.teachers) {
            if (t.subjectName.trim().isNotEmpty) {
              classSubjs.add(t.subjectName.trim());
            }
          }
        }
        if (classSubjs.isNotEmpty) {
          return classSubjs.toSet().toList()..sort();
        }
      }
      return _teacherSubjects;
    }

    List<String> initialSubjects = getAvailableSubjects(selectedClass);
    String selectedSubject = initialSubjects.isNotEmpty ? initialSubjects.first : 'General';
    DateTime selectedDueDate = DateTime.now().add(const Duration(days: 2));

    final formKey = GlobalKey<FormState>();

    if (!mounted) return;

    await showDialog(
      context: context,
      barrierDismissible: true,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          final currentSubjects = getAvailableSubjects(selectedClass);
          if (currentSubjects.isNotEmpty && !currentSubjects.contains(selectedSubject)) {
            selectedSubject = currentSubjects.first;
          }
          final dateStr = DateFormat('EEE, MMM d, yyyy').format(selectedDueDate);

          return AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            titlePadding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
            contentPadding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
            title: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: KukieAccent.violetTint,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.assignment_outlined, color: KukieAccent.violet, size: 22),
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'Create New Homework',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF0F172A)),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            content: SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 10),
                    if (_classes.isNotEmpty)
                      DropdownButtonFormField<SchoolClass>(
                        initialValue: selectedClass,
                        isExpanded: true,
                        decoration: InputDecoration(
                          labelText: 'Target Class *',
                          prefixIcon: const Icon(Icons.class_outlined, color: KukieAccent.violet, size: 18),
                          filled: true,
                          fillColor: const Color(0xFFF8FAFC),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE2E8F0))),
                        ),
                        items: _classes
                            .map((c) => DropdownMenuItem(
                                  value: c,
                                  child: Text(c.displayName, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
                                ))
                            .toList(),
                        onChanged: (val) {
                          setDialogState(() {
                            selectedClass = val;
                            final subs = getAvailableSubjects(val);
                            if (subs.isNotEmpty) {
                              selectedSubject = subs.first;
                            }
                          });
                        },
                      ),
                    const SizedBox(height: 12),

                    if (currentSubjects.isNotEmpty)
                      DropdownButtonFormField<String>(
                        initialValue: currentSubjects.contains(selectedSubject) ? selectedSubject : currentSubjects.first,
                        isExpanded: true,
                        decoration: InputDecoration(
                          labelText: 'Subject *',
                          prefixIcon: const Icon(Icons.book_outlined, color: KukieAccent.violet, size: 18),
                          filled: true,
                          fillColor: const Color(0xFFF8FAFC),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE2E8F0))),
                        ),
                        items: currentSubjects
                            .map((subj) => DropdownMenuItem(
                                  value: subj,
                                  child: Text(subj, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
                                ))
                            .toList(),
                        onChanged: (val) {
                          if (val != null) setDialogState(() => selectedSubject = val);
                        },
                      )
                    else
                      TextFormField(
                        initialValue: selectedSubject,
                        decoration: InputDecoration(
                          labelText: 'Subject *',
                          prefixIcon: const Icon(Icons.book_outlined, color: KukieAccent.violet, size: 18),
                          filled: true,
                          fillColor: const Color(0xFFF8FAFC),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE2E8F0))),
                        ),
                        onChanged: (val) => selectedSubject = val,
                      ),
                    const SizedBox(height: 12),

                    TextFormField(
                      controller: titleCtrl,
                      decoration: InputDecoration(
                        labelText: 'Assignment Title *',
                        hintText: 'e.g. Chapter 4 Exercises: Q1 to Q15',
                        prefixIcon: const Icon(Icons.title_rounded, color: KukieAccent.violet, size: 18),
                        filled: true,
                        fillColor: const Color(0xFFF8FAFC),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE2E8F0))),
                      ),
                      validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                    ),
                    const SizedBox(height: 12),

                    TextFormField(
                      controller: descCtrl,
                      maxLines: 3,
                      decoration: InputDecoration(
                        labelText: 'Detailed Instructions *',
                        prefixIcon: const Icon(Icons.description_outlined, color: KukieAccent.violet, size: 18),
                        filled: true,
                        fillColor: const Color(0xFFF8FAFC),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE2E8F0))),
                      ),
                      validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                    ),
                    const SizedBox(height: 12),

                    InkWell(
                      onTap: () async {
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: selectedDueDate,
                          firstDate: DateTime.now(),
                          lastDate: DateTime.now().add(const Duration(days: 180)),
                        );
                        if (picked != null) {
                          setDialogState(() => selectedDueDate = picked);
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF1F5F9),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: const Color(0xFFE2E8F0)),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.event_outlined, color: KukieAccent.violet, size: 18),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('Due Date', style: TextStyle(fontSize: 10, color: Color(0xFF64748B), fontWeight: FontWeight.bold)),
                                  Text(dateStr, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
                                ],
                              ),
                            ),
                            const Text('Select Date', style: TextStyle(fontSize: 12, color: KukieAccent.violet, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogCtx).pop(),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () async {
                  if (formKey.currentState!.validate() && selectedClass != null) {
                    final messenger = ScaffoldMessenger.of(context);
                    final nav = Navigator.of(dialogCtx);
                    try {
                      await _homeworkService.createHomework(
                        classId: selectedClass!.id,
                        className: selectedClass!.displayName,
                        subject: selectedSubject,
                        title: titleCtrl.text.trim(),
                        description: descCtrl.text.trim(),
                        dueDate: selectedDueDate,
                      );
                      nav.pop();
                      _loadData();
                      messenger.showSnackBar(
                        const SnackBar(content: Text('Homework published successfully!'), backgroundColor: Color(0xFF10B981)),
                      );
                    } on ApiException catch (e) {
                      messenger.showSnackBar(
                        SnackBar(content: Text('Error: ${e.message}'), backgroundColor: Colors.red),
                      );
                    } catch (e) {
                      messenger.showSnackBar(
                        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
                      );
                    }
                  }
                },
                style: FilledButton.styleFrom(
                  backgroundColor: KukieAccent.violet,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                child: const Text('Publish Assignment', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _deleteHomework(String id) async {
    await _homeworkService.deleteHomework(id);
    _loadData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Homework Assignments',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF0F172A)),
            ),
            Text('Class Tasks & Submission Guidelines', style: TextStyle(fontSize: 11, color: Color(0xFF64748B))),
          ],
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFF0F172A)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showCreateHomeworkDialog,
        backgroundColor: KukieAccent.violet,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Create Homework', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      body: RefreshIndicator(
        onRefresh: _loadData,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _homeworks.isEmpty
                ? Center(
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.assignment_outlined, size: 54, color: Color(0xFFCBD5E1)),
                            const SizedBox(height: 16),
                            const Text('No homework assignments posted yet.', style: TextStyle(fontSize: 14, color: Color(0xFF64748B))),
                            const SizedBox(height: 20),
                            FilledButton.icon(
                              onPressed: _showCreateHomeworkDialog,
                              icon: const Icon(Icons.add),
                              label: const Text('Create First Assignment'),
                              style: FilledButton.styleFrom(
                                backgroundColor: KukieAccent.violet,
                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                : ListView.builder(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(16),
                    itemCount: _homeworks.length,
                    itemBuilder: (context, index) {
                      final hw = _homeworks[index];
                      final dueStr = DateFormat('EEE, MMM d, yyyy').format(hw.dueDate);

                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFE2E8F0)),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0x05000000),
                              blurRadius: 6,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: KukieAccent.violetTint,
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Text(
                                    hw.subject,
                                    style: const TextStyle(color: KukieAccent.violet, fontWeight: FontWeight.bold, fontSize: 11.5),
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline_rounded, size: 20, color: Color(0xFFE11D48)),
                                  onPressed: () => _deleteHomework(hw.id),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(hw.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xFF0F172A))),
                            const SizedBox(height: 4),
                            Text(hw.description, style: const TextStyle(fontSize: 13, color: Color(0xFF475569), height: 1.3)),
                            const Divider(height: 20, color: Color(0xFFF1F5F9)),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text('Target: ${hw.className ?? 'Assigned Class'}', style: const TextStyle(fontSize: 11, color: Color(0xFF64748B))),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFFFFBEB),
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(color: const Color(0xFFFDE68A)),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.event_outlined, size: 13, color: Color(0xFFD97706)),
                                      const SizedBox(width: 4),
                                      Text('Due: $dueStr', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFFD97706))),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
