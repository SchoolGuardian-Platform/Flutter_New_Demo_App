import 'package:flutter/material.dart';
import '../../models/grade_entry.dart';
import '../../models/homework_entry.dart';
import '../../models/school_class.dart';
import '../../models/teacher_profile.dart';
import '../../models/user.dart';
import '../../services/appointment_service.dart';
import '../../services/auth_service.dart';
import '../../services/homework_service.dart';
import '../../services/school_management_service.dart';
import '../../services/teacher_service.dart';
import '../../theme/kukie_accent.dart';
import '../communication/private_communication_page.dart';
import '../landing_page.dart';
import 'add_grade_page.dart';
import 'manage_homework_page.dart';
import 'mark_attendance_page.dart';
import 'my_classes_page.dart';
import 'teacher_appointments_page.dart';
import 'teacher_notes_page.dart';

class TeacherPortalPage extends StatefulWidget {
  const TeacherPortalPage({super.key});

  static const routeName = '/teacher/portal';

  @override
  State<TeacherPortalPage> createState() => _TeacherPortalPageState();
}

class _TeacherPortalPageState extends State<TeacherPortalPage> {
  final _teacherService = TeacherService();
  final _schoolService = SchoolManagementService();
  final _homeworkService = HomeworkService();
  final _appointmentService = AppointmentService();

  int _currentIndex = 0;
  bool _loading = true;
  String _teacherName = 'Teacher';
  User? _currentUser;
  TeacherProfile? _teacherProfile;
  List<SchoolClass> _assignedClasses = [];
  List<HomeworkEntry> _homeworks = [];
  List<GradeEntry> _grades = [];
  List<AppointmentItem> _appointments = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    if (!mounted) return;
    setState(() => _loading = true);
    try {
      final user = await AuthService().getMe();
      final name = '${user.firstName} ${user.lastName}'.trim();
      _teacherName = name.isNotEmpty ? name : 'Teacher';

      final profile = await _teacherService.getTeacherProfile();
      final allClasses = await _schoolService.getClasses();

      final filteredClasses = allClasses.where((sc) {
        final isTeacherInClassList = sc.teachers.any((t) =>
            (t.teacherId.isNotEmpty && t.teacherId == profile.id) ||
            (t.teacherName.isNotEmpty && t.teacherName.toLowerCase() == profile.fullName.toLowerCase()));

        final isClassInProfileList = profile.assignedClasses.any((ac) {
          final cleanAc = ac.trim().toLowerCase();
          return cleanAc == sc.displayName.trim().toLowerCase() ||
                 cleanAc == sc.id.trim().toLowerCase() ||
                 cleanAc == sc.shortLabel.trim().toLowerCase();
        });

        return isTeacherInClassList || isClassInProfileList;
      }).toList();

      final activeClasses = filteredClasses.isNotEmpty ? filteredClasses : allClasses;

      final homeworks = await _homeworkService.getTeacherHomeworks();
      final grades = await _teacherService.getGradeEntries();
      final appointments = await _appointmentService.getTeacherAppointments();

      if (mounted) {
        setState(() {
          _currentUser = user;
          _teacherProfile = profile;
          _assignedClasses = activeClasses;
          _homeworks = homeworks;
          _grades = grades;
          _appointments = appointments;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  void _navigateToParentChat() async {
    User? targetUser = _currentUser;
    if (targetUser == null) {
      try {
        targetUser = await AuthService().getMe();
        if (mounted) {
          setState(() => _currentUser = targetUser);
        }
      } catch (_) {}
    }

    final user = targetUser;
    if (mounted && user != null) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => PrivateCommunicationPage(user: user),
        ),
      );
    }
  }

  void _navigateToNotes() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const TeacherNotesPage()),
    );
  }

  void _navigateToAppointments() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const TeacherAppointmentsPage()),
    );
  }

  void _navigateToMarkAttendance() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const MarkAttendancePage()),
    );
  }

  void _navigateToManageHomework() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const ManageHomeworkPage()),
    );
  }

  void _navigateToAddGrade() async {
    final added = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const AddGradePage()),
    );
    if (added == true) _loadData();
  }

  void _navigateToMyClasses() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const MyClassesPage()),
    );
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Log out?'),
        content: const Text('You\'ll need to sign in again to continue.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Log Out', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      await AuthService().logout();
      if (mounted) {
        Navigator.of(context).pushNamedAndRemoveUntil(
          LandingPage.routeName,
          (route) => false,
        );
      }
    }
  }

  Widget _buildSelectedTabContent(String firstName) {
    switch (_currentIndex) {
      case 0:
        return _buildHomeTab(firstName);
      case 1:
        return _buildClassTab();
      case 2:
        return _buildParentTab();
      case 3:
        return _buildProfileTab();
      default:
        return _buildHomeTab(firstName);
    }
  }

  @override
  Widget build(BuildContext context) {
    final firstName = _teacherName.split(' ').first;

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: KukieAccent.violetTint,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.school_rounded, color: KukieAccent.violet, size: 20),
            ),
            const SizedBox(width: 8),
            const Text(
              'Teacher Portal',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: Color(0xFF0F172A),
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Color(0xFF0F172A)),
            onPressed: _loadData,
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.account_circle_outlined, color: Color(0xFF0F172A)),
            onSelected: (val) {
              if (val == 'logout') {
                _logout();
              } else if (val == 'profile') {
                setState(() => _currentIndex = 3);
              }
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                enabled: false,
                child: Text(
                  _teacherName,
                  style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF0F172A)),
                ),
              ),
              const PopupMenuDivider(),
              const PopupMenuItem(
                value: 'profile',
                child: Row(
                  children: [
                    Icon(Icons.person_outline_rounded, size: 18, color: Color(0xFF334155)),
                    SizedBox(width: 8),
                    Text('My Profile', style: TextStyle(color: Color(0xFF334155))),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'logout',
                child: Row(
                  children: [
                    Icon(Icons.logout_rounded, size: 18, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Log Out', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: KukieAccent.violet,
        unselectedItemColor: const Color(0xFF64748B),
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
        elevation: 8,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home_rounded),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.class_outlined),
            activeIcon: Icon(Icons.class_rounded),
            label: 'Class',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people_outline_rounded),
            activeIcon: Icon(Icons.people_rounded),
            label: 'Parent',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline_rounded),
            activeIcon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadData,
              child: _buildSelectedTabContent(firstName),
            ),
    );
  }

  // ── Tab 0: Home Tab ────────────────────────────────────────────────────────
  Widget _buildHomeTab(String firstName) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // 1. Top Welcome Banner
        _TopWelcomeBanner(
          firstName: firstName,
          onTakeAttendance: _navigateToMarkAttendance,
          onCreateHomework: _navigateToManageHomework,
        ),
        const SizedBox(height: 16),

        // 2. Stat Metrics Row
        _MetricsRow(
          assignedClassesCount: _assignedClasses.length,
          activeHomeworksCount: _homeworks.length,
          gradeEntriesCount: _grades.length,
          pendingAppointmentsCount: _appointments.where((a) => a.status == 'PENDING').length,
          onClassesTap: () => setState(() => _currentIndex = 1),
          onHomeworkTap: _navigateToManageHomework,
          onGradesTap: _navigateToAddGrade,
          onChatTap: _navigateToParentChat,
        ),
        const SizedBox(height: 20),

        // 3. Teaching Schedule & Classes
        _TeachingScheduleCard(
          classes: _assignedClasses,
          onViewRoster: _navigateToMyClasses,
        ),
        const SizedBox(height: 16),

        // 4. Quick Action Shortcuts Row
        _QuickActionsRow(
          onNotes: _navigateToNotes,
          onParentMessaging: _navigateToParentChat,
          onOpenSlots: _navigateToAppointments,
        ),
        const SizedBox(height: 20),

        // 5. Parent Appointments Card
        _ParentAppointmentsCard(
          onManage: _navigateToAppointments,
        ),
        const SizedBox(height: 16),

        // 6. Recent Homework Card
        _RecentHomeworkCard(
          homeworks: _homeworks,
          onViewAll: _navigateToManageHomework,
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  // ── Tab 1: Class Tab ───────────────────────────────────────────────────────
  Widget _buildClassTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Header Banner
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: KukieAccent.violetTint,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.class_rounded, color: KukieAccent.violet, size: 20),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Class & Academics Hub',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF0F172A)),
                    ),
                    Text(
                      'Rosters, grade records, homework & attendance',
                      style: TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // 4 Core Academic Functions Grid
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.3,
          children: [
            _AcademicToolCard(
              title: 'Record Grade',
              subtitle: 'Log student marks',
              icon: Icons.grade_outlined,
              accentColor: KukieAccent.violet,
              bgColor: KukieAccent.violetTint,
              onTap: _navigateToAddGrade,
            ),
            _AcademicToolCard(
              title: 'Manage Homework',
              subtitle: 'Assign & view tasks',
              icon: Icons.assignment_outlined,
              accentColor: const Color(0xFF0284C7),
              bgColor: const Color(0xFFE0F2FE),
              onTap: _navigateToManageHomework,
            ),
            _AcademicToolCard(
              title: 'Mark Attendance',
              subtitle: 'Daily student presence',
              icon: Icons.fact_check_outlined,
              accentColor: const Color(0xFF10B981),
              bgColor: const Color(0xFFECFDF5),
              onTap: _navigateToMarkAttendance,
            ),
            _AcademicToolCard(
              title: 'Student Notes',
              subtitle: 'Pedagogical feedback',
              icon: Icons.edit_note_rounded,
              accentColor: const Color(0xFFD97706),
              bgColor: const Color(0xFFFFFBEB),
              onTap: _navigateToNotes,
            ),
          ],
        ),
        const SizedBox(height: 20),

        // Class Roster List Card
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Assigned Class Rosters',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFF0F172A)),
                  ),
                  TextButton.icon(
                    onPressed: _navigateToMyClasses,
                    icon: const Icon(Icons.open_in_new_rounded, size: 14, color: KukieAccent.violet),
                    label: const Text('Open Full Roster', style: TextStyle(fontSize: 12, color: KukieAccent.violet, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              if (_assignedClasses.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: Center(
                    child: Text('No classes assigned yet by administration.', style: TextStyle(fontSize: 12, color: Color(0xFF94A3B8))),
                  ),
                )
              else
                Column(
                  children: _assignedClasses.map((sc) {
                    final gradeStr = sc.grade.toString();
                    final sectionStr = sc.section.isNotEmpty ? sc.section : 'A';
                    final nameStr = sc.displayName.isNotEmpty ? sc.displayName : 'Grade $gradeStr-$sectionStr';

                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: KukieAccent.violetTint,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              'Grade $gradeStr-$sectionStr',
                              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: KukieAccent.violet),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(nameStr, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
                                Text('${sc.studentCount} enrolled students', style: const TextStyle(fontSize: 11, color: Color(0xFF64748B))),
                              ],
                            ),
                          ),
                          OutlinedButton(
                            onPressed: _navigateToMyClasses,
                            style: OutlinedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              side: const BorderSide(color: Color(0xFFCBD5E1)),
                            ),
                            child: const Text('Roster', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF334155))),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
            ],
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  // ── Tab 2: Parent Tab ──────────────────────────────────────────────────────
  Widget _buildParentTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Header Card
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFFECFDF5),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.people_rounded, color: Color(0xFF10B981), size: 20),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Parent Engagement Hub',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF0F172A)),
                    ),
                    Text(
                      'Direct parent messaging & office hour appointment slots',
                      style: TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // 2 Main Hero Action Cards
        Row(
          children: [
            Expanded(
              child: InkWell(
                onTap: _navigateToParentChat,
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFECFDF5),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.chat_bubble_outline_rounded, color: Color(0xFF10B981), size: 22),
                      ),
                      const SizedBox(height: 12),
                      const Text('Parent Chat', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
                      const SizedBox(height: 2),
                      const Text('Direct messaging', style: TextStyle(fontSize: 11, color: Color(0xFF64748B))),
                      const SizedBox(height: 12),
                      const Row(
                        children: [
                          Text('Open Messaging', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF10B981))),
                          Icon(Icons.arrow_forward_rounded, size: 12, color: Color(0xFF10B981)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: InkWell(
                onTap: _navigateToAppointments,
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFFBEB),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.calendar_month_outlined, color: Color(0xFFD97706), size: 22),
                      ),
                      const SizedBox(height: 12),
                      const Text('Appointment Slots', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
                      const SizedBox(height: 2),
                      const Text('Office hours scheduler', style: TextStyle(fontSize: 11, color: Color(0xFF64748B))),
                      const SizedBox(height: 12),
                      const Row(
                        children: [
                          Text('Manage Slots', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFFD97706))),
                          Icon(Icons.arrow_forward_rounded, size: 12, color: Color(0xFFD97706)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),

        // Upcoming Parent Appointments Preview
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Parent Conference Requests', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
                  TextButton(
                    onPressed: _navigateToAppointments,
                    child: const Text('View All', style: TextStyle(fontSize: 12, color: KukieAccent.violet, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              if (_appointments.isEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 12),
                  child: const Center(
                    child: Column(
                      children: [
                        Icon(Icons.event_available_outlined, size: 36, color: Color(0xFFCBD5E1)),
                        SizedBox(height: 8),
                        Text('No active appointment requests right now.', style: TextStyle(fontSize: 12, color: Color(0xFF64748B))),
                      ],
                    ),
                  ),
                )
              else
                Column(
                  children: _appointments.take(4).map((apt) {
                    final parentInitial = (apt.parentName.trim().isNotEmpty)
                        ? apt.parentName.trim().substring(0, 1).toUpperCase()
                        : 'P';
                    final displayName = (apt.parentName.trim().isNotEmpty) ? apt.parentName.trim() : 'Parent';
                    final studentDisplayName = (apt.studentName.trim().isNotEmpty) ? apt.studentName.trim() : 'Student';
                    final statusStr = apt.status.isNotEmpty ? apt.status : 'PENDING';
                    final dateStr = apt.date.isNotEmpty ? apt.date : 'Scheduled';

                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFFF1F5F9)),
                      ),
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 16,
                            backgroundColor: KukieAccent.violetTint,
                            child: Text(
                              parentInitial,
                              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: KukieAccent.violet),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(displayName, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
                                Text('Student: $studentDisplayName • $dateStr', style: const TextStyle(fontSize: 11, color: Color(0xFF64748B))),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: statusStr == 'ACCEPTED' ? const Color(0xFFECFDF5) : const Color(0xFFFFFBEB),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              statusStr,
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: statusStr == 'ACCEPTED' ? const Color(0xFF10B981) : const Color(0xFFD97706),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
            ],
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  // ── Tab 3: Profile Tab ─────────────────────────────────────────────────────
  Widget _buildProfileTab() {
    final profile = _teacherProfile ?? TeacherProfile.sample();
    final teacherNameStr = _teacherName.trim().isNotEmpty ? _teacherName.trim() : 'Teacher';
    final initial = teacherNameStr.substring(0, 1).toUpperCase();
    final emailStr = profile.email.isNotEmpty ? profile.email : 'teacher@schoolguardian.app';
    final empIdStr = profile.employeeId.isNotEmpty ? profile.employeeId : 'TCH-1001';
    final deptStr = profile.department.isNotEmpty ? profile.department : 'Academic Faculty';
    final majorStr = profile.majorField.isNotEmpty ? profile.majorField : 'Educational Pedagogy';
    final subsList = profile.assignedSubjects;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Top Profile Card
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFE2E8F0)),
            boxShadow: const [
              BoxShadow(color: Color(0x08000000), blurRadius: 10, offset: Offset(0, 4)),
            ],
          ),
          child: Column(
            children: [
              CircleAvatar(
                radius: 36,
                backgroundColor: KukieAccent.violet,
                child: Text(
                  initial,
                  style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Colors.white),
                ),
              ),
              const SizedBox(height: 12),
              Text(teacherNameStr, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFF0F172A))),
              const SizedBox(height: 2),
              Text(emailStr, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B))),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: KukieAccent.violetTint,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Faculty ID: $empIdStr',
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: KukieAccent.violet),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // Academic Info Details Card
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Academic Identity', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
              const SizedBox(height: 12),
              _ProfileDetailRow(icon: Icons.domain_rounded, label: 'Department', value: deptStr),
              const Divider(height: 20, color: Color(0xFFF1F5F9)),
              _ProfileDetailRow(icon: Icons.school_outlined, label: 'Major Field', value: majorStr),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // Assigned Subjects Card
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Assigned Subjects', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
              const SizedBox(height: 10),
              if (subsList.isEmpty)
                const Text('No specific subjects assigned.', style: TextStyle(fontSize: 12, color: Color(0xFF94A3B8)))
              else
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: subsList.map((sub) {
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF1F5F9),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.book_outlined, size: 14, color: Color(0xFF475569)),
                          const SizedBox(width: 6),
                          Text(sub, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Color(0xFF334155))),
                        ],
                      ),
                    );
                  }).toList(),
                ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        // Log Out Button
        OutlinedButton.icon(
          onPressed: _logout,
          icon: const Icon(Icons.logout_rounded, color: Colors.red, size: 18),
          label: const Text('Sign Out of Faculty Portal', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          style: OutlinedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 14),
            side: const BorderSide(color: Color(0xFFFECDD3)),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }
}

class _ProfileDetailRow extends StatelessWidget {
  const _ProfileDetailRow({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: const Color(0xFFF8FAFC),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, size: 18, color: const Color(0xFF64748B)),
        ),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(fontSize: 11, color: Color(0xFF94A3B8))),
            Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
          ],
        ),
      ],
    );
  }
}

class _AcademicToolCard extends StatelessWidget {
  const _AcademicToolCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accentColor,
    required this.bgColor,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final Color accentColor;
  final Color bgColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: bgColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: accentColor, size: 20),
            ),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
            Text(subtitle, style: const TextStyle(fontSize: 10.5, color: Color(0xFF64748B))),
          ],
        ),
      ),
    );
  }
}

// ── Web Dashboard Top Banner Component ───────────────────────────────────────
class _TopWelcomeBanner extends StatelessWidget {
  const _TopWelcomeBanner({
    required this.firstName,
    required this.onTakeAttendance,
    required this.onCreateHomework,
  });

  final String firstName;
  final VoidCallback onTakeAttendance;
  final VoidCallback onCreateHomework;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF4F46E5), Color(0xFF7C3AED)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(
            color: Color(0x334F46E5),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Welcome back, $firstName! 👋',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0x33FFFFFF),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(
                  'Faculty Portal',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          const Text(
            'Manage student attendance, publish homework, log grades, and communicate with parents.',
            style: TextStyle(
              fontSize: 12,
              color: Color(0xE6FFFFFF),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onTakeAttendance,
                  icon: const Icon(Icons.fact_check_outlined, size: 15, color: Color(0xFF4F46E5)),
                  label: const Text(
                    'Take Attendance',
                    style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: Color(0xFF4F46E5)),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onCreateHomework,
                  icon: const Icon(Icons.add, size: 15, color: Colors.white),
                  label: const Text(
                    'Create Homework',
                    style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: Colors.white),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.white54),
                    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Web Dashboard Metrics Row (4 Cards) ──────────────────────────────────────
class _MetricsRow extends StatelessWidget {
  const _MetricsRow({
    required this.assignedClassesCount,
    required this.activeHomeworksCount,
    required this.gradeEntriesCount,
    required this.pendingAppointmentsCount,
    required this.onClassesTap,
    required this.onHomeworkTap,
    required this.onGradesTap,
    required this.onChatTap,
  });

  final int assignedClassesCount;
  final int activeHomeworksCount;
  final int gradeEntriesCount;
  final int pendingAppointmentsCount;
  final VoidCallback onClassesTap;
  final VoidCallback onHomeworkTap;
  final VoidCallback onGradesTap;
  final VoidCallback onChatTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _MetricCard(
                title: 'Assigned Classes',
                value: '$assignedClassesCount',
                icon: Icons.class_outlined,
                accentColor: KukieAccent.violet,
                bgColor: KukieAccent.violetTint,
                onTap: onClassesTap,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _MetricCard(
                title: 'Active Homeworks',
                value: '$activeHomeworksCount',
                icon: Icons.assignment_outlined,
                accentColor: const Color(0xFF0284C7),
                bgColor: const Color(0xFFE0F2FE),
                onTap: onHomeworkTap,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _MetricCard(
                title: 'Grade Records',
                value: '$gradeEntriesCount',
                icon: Icons.grade_outlined,
                accentColor: const Color(0xFF10B981),
                bgColor: const Color(0xFFECFDF5),
                onTap: onGradesTap,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _MetricCard(
                title: 'Parent Chat',
                value: 'Active',
                icon: Icons.chat_bubble_outline_rounded,
                accentColor: const Color(0xFFD97706),
                bgColor: const Color(0xFFFFFBEB),
                onTap: onChatTap,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.accentColor,
    required this.bgColor,
    required this.onTap,
  });

  final String title;
  final String value;
  final IconData icon;
  final Color accentColor;
  final Color bgColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE2E8F0)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x05000000),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: bgColor,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: accentColor, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF64748B),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF0F172A),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Web Dashboard Schedule & Classes Card ────────────────────────────────────
class _TeachingScheduleCard extends StatelessWidget {
  const _TeachingScheduleCard({
    required this.classes,
    required this.onViewRoster,
  });

  final List<SchoolClass> classes;
  final VoidCallback onViewRoster;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'My Teaching Classes',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFF0F172A)),
                  ),
                  Text(
                    'Assigned sections & enrollment list',
                    style: TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                  ),
                ],
              ),
              TextButton(
                onPressed: onViewRoster,
                child: const Row(
                  children: [
                    Text('View Roster', style: TextStyle(fontSize: 12, color: KukieAccent.violet, fontWeight: FontWeight.bold)),
                    Icon(Icons.arrow_forward_rounded, size: 14, color: KukieAccent.violet),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (classes.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Center(
                child: Text(
                  'No classes assigned yet by administration.',
                  style: TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                ),
              ),
            )
          else
            Column(
              children: classes.map((c) {
                return InkWell(
                  onTap: onViewRoster,
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8FAFC),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFFF1F5F9)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: KukieAccent.violetTint,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            'Grade ${c.grade}-${c.section}',
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              color: KukieAccent.violet,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                c.displayName,
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF0F172A)),
                              ),
                              Text(
                                'Academic Year: ${c.academicYear}',
                                style: const TextStyle(fontSize: 10.5, color: Color(0xFF64748B)),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          '${c.studentCount} Students',
                          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Color(0xFF475569)),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }
}

// ── Web Dashboard Quick Action Shortcuts Row ─────────────────────────────────
class _QuickActionsRow extends StatelessWidget {
  const _QuickActionsRow({
    required this.onNotes,
    required this.onParentMessaging,
    required this.onOpenSlots,
  });

  final VoidCallback onNotes;
  final VoidCallback onParentMessaging;
  final VoidCallback onOpenSlots;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: InkWell(
            onTap: onNotes,
            borderRadius: BorderRadius.circular(14),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEEF2FF),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.edit_note_rounded, color: Color(0xFF4F46E5), size: 18),
                  ),
                  const SizedBox(height: 8),
                  const Text('Student Notes', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
                  const Text('Observation', style: TextStyle(fontSize: 10, color: Color(0xFF94A3B8))),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: InkWell(
            onTap: onParentMessaging,
            borderRadius: BorderRadius.circular(14),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFECFDF5),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.chat_bubble_outline_rounded, color: Color(0xFF10B981), size: 18),
                  ),
                  const SizedBox(height: 8),
                  const Text('Parent Chat', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
                  const Text('Real-time chat', style: TextStyle(fontSize: 10, color: Color(0xFF94A3B8))),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: InkWell(
            onTap: onOpenSlots,
            borderRadius: BorderRadius.circular(14),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFFBEB),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.calendar_month_outlined, color: Color(0xFFD97706), size: 18),
                  ),
                  const SizedBox(height: 8),
                  const Text('Open Slots', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
                  const Text('Scheduler', style: TextStyle(fontSize: 10, color: Color(0xFF94A3B8))),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ── Web Dashboard Parent Appointments Component ─────────────────────────────
class _ParentAppointmentsCard extends StatelessWidget {
  const _ParentAppointmentsCard({required this.onManage});

  final VoidCallback onManage;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Row(
                children: [
                  Icon(Icons.calendar_month_outlined, size: 18, color: KukieAccent.violet),
                  SizedBox(width: 8),
                  Text(
                    'Parent Appointments',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFF0F172A)),
                  ),
                ],
              ),
              TextButton(
                onPressed: onManage,
                child: const Row(
                  children: [
                    Text('Manage Slots', style: TextStyle(fontSize: 12, color: KukieAccent.violet, fontWeight: FontWeight.bold)),
                    Icon(Icons.arrow_forward_rounded, size: 14, color: KukieAccent.violet),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFF1F5F9)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFEF3C7),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.event_available_rounded, color: Color(0xFFD97706), size: 20),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Office Hours Availability',
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF0F172A)),
                      ),
                      Text(
                        'Publish time slots for parent conferences & accept meeting bookings.',
                        style: TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: onManage,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: KukieAccent.violet,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: const Text('Open', style: TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Web Dashboard Recent Homework Component ──────────────────────────────────
class _RecentHomeworkCard extends StatelessWidget {
  const _RecentHomeworkCard({
    required this.homeworks,
    required this.onViewAll,
  });

  final List<HomeworkEntry> homeworks;
  final VoidCallback onViewAll;

  @override
  Widget build(BuildContext context) {
    final recent = homeworks.take(3).toList();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Recent Homework Assignments',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFF0F172A)),
                  ),
                  Text(
                    'Active tasks & published submissions',
                    style: TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                  ),
                ],
              ),
              TextButton(
                onPressed: onViewAll,
                child: const Row(
                  children: [
                    Text('View All', style: TextStyle(fontSize: 12, color: KukieAccent.violet, fontWeight: FontWeight.bold)),
                    Icon(Icons.arrow_forward_rounded, size: 14, color: KukieAccent.violet),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (recent.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Center(
                child: Text(
                  'No homework assignments created yet.',
                  style: TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                ),
              ),
            )
          else
            Column(
              children: recent.map((hw) {
                final titleStr = hw.title.isNotEmpty ? hw.title : 'Homework Task';
                final subjectStr = hw.subject.isNotEmpty ? hw.subject : 'General';
                final dueStr = hw.dueDate.toString().split(' ')[0];

                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFF1F5F9)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE0F2FE),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.assignment_turned_in_outlined, color: Color(0xFF0284C7), size: 18),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              titleStr,
                              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF0F172A)),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              '$subjectStr • Due: $dueStr',
                              style: const TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }
}
